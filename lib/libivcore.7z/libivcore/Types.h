/*
	================================
	Types        2009/11/12
	================================

	The definitions of types
*/


#pragma  once

namespace LibIV
{
	namespace System
	{
		namespace Types
		{

		} // End of Types
	} // End of System	
} // End of LibIV

typedef unsigned char		uchar;
typedef unsigned int		uint;
typedef unsigned short		ushort;